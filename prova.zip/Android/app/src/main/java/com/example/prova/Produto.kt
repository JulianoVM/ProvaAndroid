package com.example.prova

import androidx.core.util.Preconditions

class Produto(
    var nome: String,
    var categoria: String,
    var preco: String,
    var qte: String
) {
    init {
        if (nome.isBlank()) { nome = "Nome vazio" }

        if (categoria.isBlank()) { categoria = "Nome vazio" }

        if (preco.isBlank()) { preco = "Nome vazio" }

        if (qte.isBlank()) { qte = "Nome vazio" }
    }
}