package com.example.prova

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

class ProdutosMain : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TelaLayout()
        }
    }
}

@Composable
fun TelaLayout() {

    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "telaCadastro") {
        composable("telaCadastro") { TelaCadastro(navController = navController) }
        composable("telaLista") { TelaLista(navController = navController) }
        composable("telaDetalhes") { TelaDetalhes(navController = navController) }
    }
}

@Composable
fun TelaCadastro(navController: NavController) {

    var nome by remember { mutableStateOf("") }
    var categoria by remember { mutableStateOf("") }
    var preco by remember { mutableStateOf("") }
    var qte by remember { mutableStateOf("") }
    var produtos by remember { mutableStateOf(listOf<Produto>()) }

    val context = LocalContext.current

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {

        Text(text = "Cadastro de Produtos", fontSize = 25.sp)

        Spacer(modifier = Modifier.height(15.dp))

        TextField(value = nome,
            onValueChange = { nome = it },
            label = { Text(text = "Digite o nome do produto") })

        Spacer(modifier = Modifier.height(5.dp))

        TextField(value = categoria,
            onValueChange = { categoria = it },
            label = { Text(text = "Digite a categoria do produto") })

        Spacer(modifier = Modifier.height(5.dp))

        TextField(value = preco,
            onValueChange = { preco = it },
            label = { Text(text = "Digite o preço do produto") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
        )

        Spacer(modifier = Modifier.height(5.dp))

        TextField(value = qte,
            onValueChange = { qte = it },
            label = { Text(text = "Digite a quantidade em estoque") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))

        Spacer(modifier = Modifier.height(15.dp))

        Button(onClick = {
            if (nome.isBlank() || categoria.isBlank() || preco.isBlank() || qte.isBlank()) {
                Toast.makeText(context,
                    "Preencha todos os campos!",
                    Toast.LENGTH_SHORT).show()
            } else {
                produtos = produtos + Produto(nome, categoria, preco, qte)

                nome = ""
                categoria = ""
                preco = ""
                qte = ""

                Toast.makeText(context,
                    "Produto cadastrado com sucesso!",
                    Toast.LENGTH_SHORT).show()
            }
        }) {
            Text(text = "Cadastrar produto")
        }

        Spacer(modifier = Modifier.height(70.dp))

        Button(onClick = {
            navController.currentBackStackEntry?.savedStateHandle?.set("produtos", produtos)
            navController.navigate("telaLista")
        }) {
            Text(text = "Lista de produtos")
        }
    }
}

@Composable
fun TelaLista(navController: NavController) {
    val produtos = navController.previousBackStackEntry?.savedStateHandle?.get<List<Produto>>("produtos")

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(text = "Lista de Produtos", fontSize = 24.sp)
        Spacer(modifier = Modifier.height(20.dp))

        LazyColumn {
            produtos?.let {
                items(it) { produto ->
                    Column {
                        Text(text = "${produto.nome} (${produto.qte})")

                        Spacer(modifier = Modifier.height(10.dp))

                        Button(onClick = {
                            navController.currentBackStackEntry?.savedStateHandle?.set("produto", produto)
                            navController.navigate("telaDetalhes")
                        }) {
                            Text(text = "Ver detalhes")
                        }

                        Spacer(modifier = Modifier.height(15.dp))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(onClick = {
            navController.popBackStack()
        }) {
            Text(text = "Voltar")
        }
    }
}

@Composable
fun TelaDetalhes(navController: NavController) {
    val produto = navController.previousBackStackEntry?.savedStateHandle?.get<Produto>("produto")

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(text = "Detalhes do Produto", fontSize = 24.sp)
        Spacer(modifier = Modifier.height(20.dp))

        produto?.let {
            Text(text = "Nome: ${it.nome}")
            Text(text = "Categoria: ${it.categoria}")
            Text(text = "Preço: ${it.preco}")
            Text(text = "Quantidade: ${it.qte}")
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(onClick = {
            navController.popBackStack()
        }) {
            Text(text = "Voltar")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewLayout() {
    TelaLayout()
}
