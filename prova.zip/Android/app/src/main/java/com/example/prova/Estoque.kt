package com.example.prova

class Estoque {

}